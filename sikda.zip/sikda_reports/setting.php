<?php
//$server="localhost";
//$db="sikda"; 
//$user="SIKDA"; 
//$pass="SIKDA12345%"; 
// $db="sikda_puskesmas"; 
// $user="root"; 
// $pass="root"; 
$db="sikda_la"; 
$user="root"; 
$pass=""; 
$server="localhost";
$version="0.1";
$pgport=5432;
$pchartfolder="./class/pchart2";
?>
